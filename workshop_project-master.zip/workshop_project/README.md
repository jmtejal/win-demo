# Welcome to the Ansible for Windows Automation workshop!

![Ansible Automation Platform](https://raw.githubusercontent.com/ansible/workshops/master/images/rh-ansible-automation-platform.png)